using JardinEsperanzaWeb.Models;

namespace JardinEsperanzaWeb.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            if (context.Plants.Any()) return; // DB already seeded

            var plants = new Plant[] {
            new Plant { Nombre = "Clavel", Tipo = "Sol", PrecioBolsa = 4.0m, PrecioMaceta = 10.0m, Cantidad = 50 },
            new Plant { Nombre = "Rosa", Tipo = "Sol", PrecioBolsa = 3.0m, PrecioMaceta = 10.0m, Cantidad = 40 },
            new Plant { Nombre = "Chula", Tipo = "Sol", PrecioBolsa = 2.0m, PrecioMaceta = 4.0m, Cantidad = 60 },
            new Plant { Nombre = "Coleo", Tipo = "Sombra", PrecioBolsa = 3.0m, PrecioMaceta = 8.0m, Cantidad = 30 },
            new Plant { Nombre = "Veranera", Tipo = "Sol", PrecioBolsa = 4.0m, PrecioMaceta = 4.0m, Cantidad = 20 },
            new Plant { Nombre = "Flor de las once", Tipo = "Sol", PrecioBolsa = 2.0m, PrecioMaceta = null, Cantidad = 25 },
            new Plant { Nombre = "Duranta", Tipo = "Sol", PrecioBolsa = 3.0m, PrecioMaceta = null, Cantidad = 18 },
            new Plant { Nombre = "Cenizo", Tipo = "Sol", PrecioBolsa = 2.0m, PrecioMaceta = 2.5m, Cantidad = 22 },
            new Plant { Nombre = "Flor de muerto", Tipo = "Sol", PrecioBolsa = 2.0m, PrecioMaceta = null, Cantidad = 40 },
            new Plant { Nombre = "Sombrero chino", Tipo = "Sol", PrecioBolsa = 3.5m, PrecioMaceta = 4.0m, Cantidad = 15 },
            new Plant { Nombre = "Narcisa", Tipo = "Sol", PrecioBolsa = 4.0m, PrecioMaceta = null, Cantidad = 12 },
            new Plant { Nombre = "Cambray", Tipo = "Sol", PrecioBolsa = 4.0m, PrecioMaceta = null, Cantidad = 10 },
            new Plant { Nombre = "Bandera", Tipo = "Sol", PrecioBolsa = 3.0m, PrecioMaceta = null, Cantidad = 14 },
            new Plant { Nombre = "Jupiter", Tipo = "Sol", PrecioBolsa = 3.0m, PrecioMaceta = 8.0m, Cantidad = 8 },
            new Plant { Nombre = "Tuja", Tipo = "Sol", PrecioBolsa = 3.5m, PrecioMaceta = 8.0m, Cantidad = 20 },
            new Plant { Nombre = "Mussaenda", Tipo = "Sol", PrecioBolsa = 3.5m, PrecioMaceta = 5.0m, Cantidad = 12 },
            new Plant { Nombre = "Allamanda", Tipo = "Sol", PrecioBolsa = 3.5m, PrecioMaceta = null, Cantidad = 10 },
            new Plant { Nombre = "Heliconia", Tipo = "Sol", PrecioBolsa = null, PrecioMaceta = null, Cantidad = 6 },
            new Plant { Nombre = "Hortensia", Tipo = "Sombra", PrecioBolsa = 8.0m, PrecioMaceta = 15.0m, Cantidad = 10 },
            new Plant { Nombre = "Lengua de suegra", Tipo = "Sombra", PrecioBolsa = 3.0m, PrecioMaceta = 10.0m, Cantidad = 18 },
            new Plant { Nombre = "Colocasia", Tipo = "Sombra", PrecioBolsa = 5.0m, PrecioMaceta = null, Cantidad = 9 },
            new Plant { Nombre = "Caladium", Tipo = "Sombra", PrecioBolsa = null, PrecioMaceta = 8.0m, Cantidad = 11 },
            new Plant { Nombre = "Zebrina", Tipo = "Sombra", PrecioBolsa = 5.0m, PrecioMaceta = null, Cantidad = 16 },
            new Plant { Nombre = "Millonarias", Tipo = "Sol", PrecioBolsa = null, PrecioMaceta = null, Cantidad = 20 },
            new Plant { Nombre = "Príncipe negro", Tipo = "Sol", PrecioBolsa = null, PrecioMaceta = null, Cantidad = 5 },
            };

            context.Plants.AddRange(plants);
            context.SaveChanges();
        }
    }
}
