using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace JardinEsperanzaWeb.Models
{
    public class Order
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; } = DateTime.UtcNow;

        public int ClientId { get; set; }
        public Client Client { get; set; }

        public int PlantId { get; set; }
        public Plant Plant { get; set; }

        public int Cantidad { get; set; }
        [Column(TypeName = "decimal(10,2)")]
        public decimal PrecioUnitario { get; set; }
        [Column(TypeName = "decimal(10,2)")]
        public decimal Total { get; set; }
    }
}
