using System.ComponentModel.DataAnnotations;

namespace JardinEsperanzaWeb.Models
{
    public class Client
    {
        public int Id { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
    }
}
