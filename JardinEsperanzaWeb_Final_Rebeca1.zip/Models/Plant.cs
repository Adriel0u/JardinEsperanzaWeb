using System.ComponentModel.DataAnnotations;

namespace JardinEsperanzaWeb.Models
{
    public class Plant
    {
        public int Id { get; set; }
        [Required]
        public string Nombre { get; set; }
        public string Tipo { get; set; } // "Sol" o "Sombra"
        public decimal? PrecioBolsa { get; set; }
        public decimal? PrecioMaceta { get; set; }
        public int Cantidad { get; set; }
    }
}
