JardinEsperanzaWeb - Proyecto completo con catálogo cargado

Contraseña del vendedor: Rebeca1

Instrucciones rápidas:
1. Necesitas .NET 7 SDK y dotnet-ef.
2. En la carpeta del proyecto:
   dotnet restore
   dotnet tool install --global dotnet-ef --version 7.*
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   dotnet run

El proyecto incluye datos iniciales (catálogo) que se insertarán si la tabla Plants está vacía.
