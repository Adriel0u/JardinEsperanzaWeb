using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using JardinEsperanzaWeb.Data;
using JardinEsperanzaWeb.Models;

namespace JardinEsperanzaWeb.Pages.Cliente
{
    public class CatalogoModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public CatalogoModel(ApplicationDbContext context) { _context = context; }
        public IList<Plant> Plants { get; set; } = new List<Plant>();

        public async Task OnGetAsync()
        {
            Plants = await _context.Plants.AsNoTracking().ToListAsync();
        }
    }
}
