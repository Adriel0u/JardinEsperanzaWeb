using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using JardinEsperanzaWeb.Data;
using JardinEsperanzaWeb.Models;
using System.ComponentModel.DataAnnotations;

namespace JardinEsperanzaWeb.Pages
{
    public class PedidoModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public PedidoModel(ApplicationDbContext context) { _context = context; }

        public IList<Plant> Plants { get; set; } = new List<Plant>();

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public string Message { get; set; }

        public class InputModel {
            [Required] public string Nombre { get; set; }
            [Required] public string Direccion { get; set; }
            [Required] public string Telefono { get; set; }
        }

        public async Task OnGetAsync()
        {
            Plants = await _context.Plants.AsNoTracking().ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync(int PlantId, int Cantidad)
        {
            Plants = await _context.Plants.AsNoTracking().ToListAsync();

            if (!ModelState.IsValid) return Page();

            var plant = await _context.Plants.FindAsync(PlantId);
            if (plant == null) { ModelState.AddModelError(string.Empty, "Planta no encontrada."); return Page(); }
            if (plant.Cantidad < Cantidad) { ModelState.AddModelError(string.Empty, "Stock insuficiente."); return Page(); }

            // save or find client
            var client = await _context.Clients.FirstOrDefaultAsync(c => c.Nombre == Input.Nombre && c.Telefono == Input.Telefono);
            if (client == null)
            {
                client = new Client { Nombre = Input.Nombre, Direccion = Input.Direccion, Telefono = Input.Telefono };
                _context.Clients.Add(client);
                await _context.SaveChangesAsync();
            }

            var precio = plant.PrecioBolsa ?? 0m;
            var order = new Order {
                ClientId = client.Id,
                PlantId = plant.Id,
                Cantidad = Cantidad,
                PrecioUnitario = precio,
                Total = precio * Cantidad,
                Fecha = DateTime.UtcNow
            };
            _context.Orders.Add(order);
            plant.Cantidad -= Cantidad;
            _context.Plants.Update(plant);
            await _context.SaveChangesAsync();

            Message = "Gracias, tu pedido ha sido registrado.";
            // clear input
            Input = new InputModel();
            return Page();
        }
    }
}
