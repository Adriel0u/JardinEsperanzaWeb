using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace JardinEsperanzaWeb.Pages.Vendedor
{
    public class LoginModel : PageModel
    {
        private readonly IConfiguration _config;
        public LoginModel(IConfiguration config) { _config = config; }
        public string Error { get; set; }

        public IActionResult OnGet() => Page();

        public IActionResult OnPost(string Password)
        {
            var correct = _config.GetSection("Vendedor").GetValue<string>("Password") ?? "";
            if (Password == correct)
            {
                // set a simple cookie valid 1 hour
                Response.Cookies.Append("VendedorAuth", "1", new Microsoft.AspNetCore.Http.CookieOptions { HttpOnly = true, Expires = DateTimeOffset.Now.AddHours(1)});
                return RedirectToPage("/Vendedor/Plantas");
            }
            Error = "Contraseña incorrecta";
            return Page();
        }
    }
}
