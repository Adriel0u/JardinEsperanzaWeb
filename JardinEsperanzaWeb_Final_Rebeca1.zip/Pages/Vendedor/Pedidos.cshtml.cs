using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using JardinEsperanzaWeb.Data;
using JardinEsperanzaWeb.Models;

namespace JardinEsperanzaWeb.Pages.Vendedor
{
    public class PedidosModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public PedidosModel(ApplicationDbContext context) { _context = context; }

        public IList<Order> Orders { get; set; } = new List<Order>();
        public bool Autenticado { get; set; }

        public async Task OnGetAsync()
        {
            Autenticado = Request.Cookies.ContainsKey("VendedorAuth");
            Orders = await _context.Orders
                .Include(o => o.Client)
                .Include(o => o.Plant)
                .AsNoTracking()
                .ToListAsync();
        }
    }
}
