using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using JardinEsperanzaWeb.Data;
using JardinEsperanzaWeb.Models;

namespace JardinEsperanzaWeb.Pages.Vendedor
{
    public class PlantasModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public PlantasModel(ApplicationDbContext context) { _context = context; }

        public IList<Plant> Plants { get; set; } = new List<Plant>();
        public bool Autenticado { get; set; }

        public async Task OnGetAsync()
        {
            Autenticado = Request.Cookies.ContainsKey("VendedorAuth");
            Plants = await _context.Plants.AsNoTracking().ToListAsync();
        }

        public async Task<IActionResult> OnPostAsync(string Nombre, string Tipo, decimal? PrecioBolsa, decimal? PrecioMaceta, int Cantidad)
        {
            Autenticado = Request.Cookies.ContainsKey("VendedorAuth");
            if (!Autenticado) return RedirectToPage("/Vendedor/Login");

            var plant = new Plant { Nombre = Nombre, Tipo = Tipo, PrecioBolsa = PrecioBolsa, PrecioMaceta = PrecioMaceta, Cantidad = Cantidad };
            _context.Plants.Add(plant);
            await _context.SaveChangesAsync();
            return RedirectToPage();
        }
    }
}
